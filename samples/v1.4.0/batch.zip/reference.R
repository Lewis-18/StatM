# Independent R reference; package algorithms may differ.
# install.packages(c("psych", "car", "lmtest", "effectsize"))
df <- read.csv("469102e7-224d-455f-a183-f5c55652402d.csv", check.names=FALSE, colClasses="character", na.strings="")
cols <- c("X1", "category")
alpha <- 0.05
reference <- read.csv("c3719716-9a7a-49fb-acc9-cd187153eec7.csv", check.names=FALSE, colClasses="character", na.strings="")
# Preserve literal category codes (001, NA); numeric conversion is explicit per mapped field.
# Descriptive comparison only; no independent-sample significance tests.
x <- df[["X1"]]
y <- reference[["X1"]]
x <- as.numeric(x); y <- as.numeric(y)
x <- x[is.finite(x)]; y <- y[is.finite(y)]
print(summary(x)); print(summary(y))
# install.packages("transport")
print(transport::wasserstein1d(x,y))
x <- df[["category"]]
y <- reference[["category"]]
x <- as.character(x[!is.na(x)]); y <- as.character(y[!is.na(y)])
levels <- sort(union(x,y))
a <- prop.table(table(factor(x,levels=levels)))
b <- prop.table(table(factor(y,levels=levels)))
print(cbind(a,b)); print(sum(abs(a-b))/2)
