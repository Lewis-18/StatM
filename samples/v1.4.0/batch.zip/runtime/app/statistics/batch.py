"""Descriptive two-dataset comparison; distances never become anomaly scores."""
import numpy as np
import pandas as pd
from scipy import stats
from app.utils.common import fail, chart


def run(df, p, reference=None, metadata=None):
    if reference is None or not p.mappings or not p.metadata_confirmed:
        fail('请选择对比数据、字段映射，并确认单位和编码口径。')
    metadata = metadata or {}
    if len({f.left for f in p.mappings}) != len(p.mappings) or len({f.right for f in p.mappings}) != len(p.mappings):
        fail('每侧映射字段不得重复。')
    if p.columns != [f.left for f in p.mappings]:
        fail('分析变量与左侧映射不一致。')
    tables, charts, warnings, summary = {}, [], [], []
    for i, field in enumerate(p.mappings):
        a, b = field.left, field.right
        if a not in df or b not in reference:
            fail('映射字段不存在，请重新选择。')
        left_info = metadata.get('left', {}).get(a, {})
        right_info = metadata.get('right', {}).get(b, {})
        units = [str(info.get('unit', '')).strip() for info in (left_info, right_info)]
        if field.kind == 'numeric' and all(units) and units[0] != units[1]:
            fail('数值字段单位不一致，请先转换数据并更新字典后再对比。')
        if field.kind == 'category' and left_info.get('codes') and right_info.get('codes') and left_info['codes'] != right_info['codes']:
            fail('类别编码含义不一致，请先统一数据与字典后再对比。')
        if field.kind == 'numeric':
            if any(info.get('scale') in ('nominal', 'ordinal') for info in (left_info, right_info)):
                fail('已标记名义或有序尺度的字段请使用类别占比对比。')
            if not pd.api.types.is_numeric_dtype(df[a]) or not pd.api.types.is_numeric_dtype(reference[b]):
                fail('数值映射需要两侧均为数值字段。')
            x = df[a].replace([np.inf, -np.inf], np.nan)
            y = reference[b].replace([np.inf, -np.inf], np.nan)
        else:
            # No silent string-to-number conversion; codes such as 001 stay distinct.
            if pd.api.types.is_numeric_dtype(df[a]) != pd.api.types.is_numeric_dtype(reference[b]):
                fail('类别字段存储类型不一致，请先统一编码；不自动转换文本编号。')
            x, y = df[a], reference[b]
        missing_x, missing_y = int(x.isna().sum()), int(y.isna().sum())
        if p.missing == 'error' and (missing_x or missing_y):
            fail('映射字段包含缺失或无穷值，请先处理或更改缺失策略。')
        x, y = x.dropna(), y.dropna()
        if not len(x) or not len(y):
            fail('每个映射字段在两批数据中均需至少一个有效值。')
        prefix = f'{i+1}. {a} ↔ {b}'
        row = {'variable': a, 'reference variable': b, 'kind': field.kind, 'left rows': len(df), 'right rows': len(reference),
               'left n': len(x), 'right n': len(y), 'left missing': missing_x, 'right missing': missing_y,
               'left missing ratio': missing_x/len(df), 'right missing ratio': missing_y/len(reference)}
        if field.kind == 'numeric':
            x, y = x.to_numpy(dtype=float), y.to_numpy(dtype=float)
            distance = stats.wasserstein_distance(x, y)
            row.update({'unit': units[0] or units[1] or '未记录', 'Wasserstein distance': distance,
                        'mean difference B-A': y.mean()-x.mean()})
            descriptions = []
            for name, values in (('A', x), ('B', y)):
                descriptions.append({'batch': name, 'n': len(values), 'mean': values.mean(),
                                     'std': values.std(ddof=1) if len(values)>1 else None, 'median': np.median(values),
                                     'min': values.min(), 'max': values.max()})
            tables[prefix+' · 数值概况'] = descriptions
            combined = np.concatenate((x, y))
            edges = np.histogram_bin_edges(combined, bins=min(30, max(5, int(np.sqrt(len(combined))))))
            panels = []
            for name, values in (('A', x), ('B', y)):
                counts = np.histogram(values, bins=edges)[0]
                panels.append({'name': name, 'n': len(values), 'shown': len(values), 'counts': counts.tolist()})
            charts.append(chart(prefix+' · 批次分布', 'facet', {'panels': panels, 'mode': 'histogram', 'edges': edges,
                                'proportion': True, 'n': len(x)+len(y)}, xLabel=a, yLabel='有效样本占比'))
            if not all(units):
                warnings.append(f'{prefix}：字典单位未完整记录，采用用户确认的口径。')
        else:
            x, y = x.astype(str), y.astype(str)
            categories = sorted(set(x)|set(y))
            if len(categories) > 50:
                fail('类别超过 50 个，请先合并类别或减少字段。')
            px = x.value_counts().reindex(categories, fill_value=0)/len(x)
            py = y.value_counts().reindex(categories, fill_value=0)/len(y)
            row['total variation distance'] = float(np.abs(px-py).sum()/2)
            tables[prefix+' · 类别占比'] = [{'category': c, 'A count': int((x == c).sum()), 'B count': int((y == c).sum()),
                                          'A proportion': px[c], 'B proportion': py[c], 'difference B-A': py[c]-px[c]} for c in categories]
            charts.append(chart(prefix+' · 类别占比', 'category_bar', {'categories': categories,
                                'series': [{'name': 'A', 'values': px.to_list()}, {'name': 'B', 'values': py.to_list()}]}, xLabel=a, yLabel='有效样本占比'))
        summary.append(row)
    tables = {'批次对比汇总': summary, **tables}
    if metadata.get('related'):
        warnings.append('两批数据具有清洗版本关系；结果为相关版本的描述性对比。')
    return {'tables': tables, 'charts': charts, 'warnings': warnings,
            'notes': ['A 为当前数据集，B 为对比数据集；各字段分别删除缺失或无穷值，表中报告有效样本量及缺失率。',
                      '数值距离为原始量纲 Wasserstein-1，不能跨不同量纲排名或套用统一异常阈值；类别距离为总变差距离。',
                      '直方图使用两批合并范围的相同等宽分箱，以各自有效样本量计算占比；缺失率另列。',
                      '仅作描述性比较，不计算独立样本检验 p 值；差异不自动归因于批次、清洗或因果效应。单位与编码已由用户确认。']}
