"""Gaussian maximum-likelihood exploratory factor analysis, distinct from PCA."""
import warnings
import numpy as np
from scipy import stats
from sklearn.decomposition import FactorAnalysis
from sklearn.exceptions import ConvergenceWarning
from app.utils.common import numeric, fail, chart


def run(df, p):
    if len(p.columns) < 3:
        fail('EFA 至少需要三个数值变量。')
    frame = numeric(df, p.columns, p.missing)
    n, m = frame.shape
    if n <= m+1:
        fail('EFA 完整样本量必须大于变量数加一。')
    k = p.components or 1
    degrees = ((m-k)**2-m-k)/2
    if k >= m or degrees < 0:
        fail('因子数过多，模型欠识别；请减少因子数。')
    z = (frame.to_numpy(dtype=float)-frame.mean().to_numpy())/frame.std(ddof=1).to_numpy()
    correlation = np.corrcoef(z, rowvar=False)
    eigenvalues = np.linalg.eigvalsh(correlation)[::-1]
    if eigenvalues[-1] <= 1e-8:
        fail('相关矩阵奇异或接近奇异，请移除重复或近线性相关变量。')
    inverse = np.linalg.inv(correlation)
    partial = -inverse/np.sqrt(np.outer(np.diag(inverse), np.diag(inverse)))
    np.fill_diagonal(partial, 0)
    squared = correlation**2
    np.fill_diagonal(squared, 0)
    denominator = squared.sum()+np.square(partial).sum()
    kmo = squared.sum()/denominator if denominator else None
    item_denom = squared.sum(axis=0)+np.square(partial).sum(axis=0)
    item_kmo = np.divide(squared.sum(axis=0), item_denom, out=np.full(m, np.nan), where=item_denom > 0)
    bartlett = -(n-1-(2*m+5)/6)*np.linalg.slogdet(correlation)[1]
    model = FactorAnalysis(n_components=k, rotation=None if p.rotation == 'none' else 'varimax',
                           svd_method='lapack', max_iter=1000, tol=1e-4, random_state=937)
    with warnings.catch_warnings(record=True) as captured:
        warnings.simplefilter('always', ConvergenceWarning)
        model.fit(z)
    if any(issubclass(w.category, ConvergenceWarning) for w in captured) or model.n_iter_ >= 1000:
        fail('EFA 未收敛，请减少因子数或检查变量与样本。')
    loads = model.components_.T
    # Fix arbitrary factor signs for a stable, documented presentation.
    for j in range(k):
        if loads[np.abs(loads[:, j]).argmax(), j] < 0:
            loads[:, j] *= -1
    communalities = np.square(loads).sum(axis=1)
    # sklearn ML uses divisor n; restore the sample-standardized variance scale.
    scale = (n-1)/n
    loads = loads/np.sqrt(scale)
    communalities = communalities/scale
    uniqueness = model.noise_variance_/scale
    notices = [f'完整案例分析：删除 {len(df)-n} 行。']
    if np.any(uniqueness < .005) or np.any(communalities > .995):
        notices.append('出现接近零的独特方差，可能为边界解；请检查因子数和变量。')
    if n < max(100, 5*m):
        notices.append('样本量较少；载荷稳定性需结合共同度、题项数与外部样本判断。')
    # Correlation-eigenvalue parallel analysis is a retention aid, not an ML fit test.
    rng = np.random.default_rng(937)
    parallel_n = min(n, 5000)
    base = z[np.sort(rng.choice(n, parallel_n, replace=False))] if n > parallel_n else z
    simulations = np.empty((100, m))
    for i in range(100):
        permuted = np.column_stack([rng.permutation(base[:, j]) for j in range(m)])
        simulations[i] = np.linalg.eigvalsh(np.corrcoef(permuted, rowvar=False))[::-1]
    observed = np.linalg.eigvalsh(np.corrcoef(base, rowvar=False))[::-1]
    benchmark = np.quantile(simulations, .95, axis=0)
    labels = [f'F{i+1}' for i in range(k)]
    fitted = loads @ loads.T+np.diag(uniqueness)
    residual = correlation-fitted
    off_diagonal = residual[np.triu_indices(m, 1)]
    tables = {'因子模型': [{'n': n, 'items': m, 'factors': k, 'rotation': p.rotation, 'iterations': model.n_iter_,
                          'KMO': kmo, 'Bartlett chi2': bartlett, 'df': m*(m-1)//2,
                          'p': stats.chi2.sf(bartlett, m*(m-1)//2), 'RMS off-diagonal residual': np.sqrt(np.mean(off_diagonal**2))}],
              '因子载荷': [{'variable': name, **{labels[j]: loads[i, j] for j in range(k)},
                           'communality': communalities[i], 'uniqueness': uniqueness[i], 'KMO': item_kmo[i]} for i, name in enumerate(p.columns)],
              '因子方差': [{'factor': labels[j], 'sum squared loadings': np.square(loads[:, j]).sum(),
                           'proportion total variance': np.square(loads[:, j]).sum()/m} for j in range(k)],
              '平行分析': [{'component': i+1, 'observed eigenvalue': observed[i], 'random 95%': benchmark[i],
                           'above benchmark': bool(observed[i] > benchmark[i]), 'n': parallel_n} for i in range(m)]}
    charts = [chart('EFA · 平行分析', 'category_bar', {'categories': [str(i+1) for i in range(m)],
              'series': [{'name': '观测相关特征值', 'values': observed}, {'name': '随机特征值 95%', 'values': benchmark}], 'n': parallel_n}, xLabel='序号', yLabel='特征值')]
    for j, label in enumerate(labels):
        charts.append(chart('EFA · '+label, 'bar', {'x': p.columns, 'y': loads[:, j]}, yLabel='因子载荷'))
    return {'tables': tables, 'charts': charts, 'warnings': notices,
            'notes': ['EFA 使用高斯最大似然公共因子模型与 Pearson 相关；按样本标准差标准化，支持不旋转或正交 Varimax。',
                      '因子数由用户设定；平行分析使用相关矩阵特征值、100 次逐列置换、95% 分位、seed 937，最多 5000 行；仅作保留因子的辅助证据。',
                      'KMO 与 Bartlett 基于全部完整案例；Bartlett 拒绝单位相关矩阵不证明模型正确。载荷符号以绝对值最大题项为正。',
                      '本模块不是 PCA 或验证性因子分析；未计算多分相关。少类别有序题项、非正态数据和边界解需另行评估。因子方差占比相对于全部标准化变量方差。']}
