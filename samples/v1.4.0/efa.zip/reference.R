# Independent R reference; package algorithms may differ.
# install.packages(c("psych", "car", "lmtest", "effectsize"))
df <- read.csv("469102e7-224d-455f-a183-f5c55652402d.csv", check.names=FALSE)
cols <- c("X1", "X2", "X3", "X4", "X5", "X6")
alpha <- 0.05
d <- df[, cols, drop=FALSE]
for (col in cols) d[[col]][!is.finite(d[[col]])] <- NA
d <- d[complete.cases(d), , drop=FALSE]
fit <- factanal(d, factors=2, rotation="varimax")
print(fit, cutoff=0)
# ML implementations, signs and factor order may differ; StatM uses sklearn EM.
# StatM parallel analysis uses 100 permutations and the 95th percentile, with Python seed 937.
