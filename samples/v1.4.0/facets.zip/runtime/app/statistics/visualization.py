"""Exploratory charts with aligned complete cases and reproducible sampling."""
import itertools
import numpy as np
import pandas as pd
from scipy import stats
from app.statistics.descriptive import distribution
from app.utils.common import numeric, fail, chart

LIMIT = 2000

def run(df, p):
    kind = p.chart_type
    cols = p.columns
    distributions = {'histogram': 'Histogram', 'boxplot': 'Boxplot', 'ecdf': 'ECDF', 'density': 'Density', 'qq': 'Normal Q-Q'}
    limits = {'scatter': (2, 2), 'scatter3d': (3, 3), 'bubble': (3, 3), 'parallel': (3, 8),
              'scatter_matrix': (2, 6), 'grouped_box': (1, 1), 'violin': (1, 1), 'category_bar': (1, 1),
              **{k: (1, 1) for k in distributions}}
    low, high = limits[kind]
    if not low <= len(cols) <= high or len(set(cols)) != len(cols):
        fail(f'此图需要 {low} 至 {high} 个不重复变量；选择顺序决定坐标轴。')
    if any(c not in df.columns for c in cols):
        fail('变量不存在，请重新选择。')
    if p.label and p.label not in df.columns:
        fail('记录标签字段不存在，请重新选择。')
    if p.group and (p.group not in df.columns or p.group in cols):
        fail('分组字段必须存在，且不能与绘图变量重复。')
    if kind in ('grouped_box', 'violin') and not p.group:
        fail('分组箱线图需要分组字段。')
    if p.facet and (kind not in ('scatter', 'histogram') or not p.group):
        fail('分面需要散点图或直方图及一个分组字段。')
    if kind in distributions and p.group and not (kind == 'histogram' and p.facet):
        fail('单变量分布图不使用分组；比较分组请使用分组箱线或小提琴图。')

    if kind == 'category_bar':
        frame = df[cols + ([p.group] if p.group else [])].copy()
        if p.missing == 'error' and frame.isna().any().any():
            fail('绘图字段包含缺失值，请先清洗或选择删除缺失行。')
        frame = frame.dropna()
        if len(frame) < 1:
            fail('没有可绘制的完整记录。')
    else:
        frame = numeric(df, cols, p.missing, minimum=1 if kind in distributions else 3, constant=True)
        if p.group:
            # Keep row identity: numeric() removed rows jointly, never column by column.
            group = df.loc[frame.index, p.group]
            if p.missing == 'error' and group.isna().any():
                fail('分组字段包含缺失值。')
            frame = frame.loc[group.notna()].copy()
            frame[p.group] = group.loc[frame.index]
            if len(frame) < 3:
                fail('删除分组缺失后至少需要 3 个完整记录。')
    if p.group:
        frame[p.group] = frame[p.group].astype(str)
        groups = sorted(frame[p.group].unique().tolist())
        if len(groups) > 12:
            fail('分组超过 12 类，请选择类别较少的字段。')
    else:
        groups = ['全部样本']
    n = len(frame)
    sampled = kind in ('scatter', 'scatter3d', 'bubble', 'parallel', 'scatter_matrix') and n > LIMIT
    sample = frame.sample(LIMIT, random_state=937).sort_index() if sampled else frame
    point_groups = sample[p.group].tolist() if p.group else ['全部样本'] * len(sample)
    labels = [f'记录 {int(i)+1}' if isinstance(i, (int, np.integer)) else str(i) for i in sample.index]
    if p.label:
        labels = [str(value) if pd.notna(value) else fallback
                  for value, fallback in zip(df.loc[sample.index, p.label], labels)]
    data = {'points': sample[cols].to_numpy().tolist() if kind != 'category_bar' else [],
            'groups': point_groups, 'categories': groups, 'labels': labels, 'n': n, 'shown': len(sample),
            'row_ids': df.index.get_indexer(sample.index).tolist() if kind in ('scatter','scatter3d','scatter_matrix','parallel','bubble') else []}
    charts = []
    tables = {'绘图样本': [{'n': n, '显示样本': len(sample), '删除行数': len(df)-n}]}
    if p.facet:
        panels = []
        if kind == 'histogram':
            edges = np.histogram_bin_edges(frame[cols[0]], bins=min(30, max(5, int(np.sqrt(n)))))
            for g in groups:
                values = frame.loc[frame[p.group] == g, cols[0]].to_numpy()
                panels.append({'name': g, 'n': len(values), 'shown': len(values), 'counts': np.histogram(values, bins=edges)[0].tolist()})
            facet_data = {'panels': panels, 'mode': 'histogram', 'edges': edges, 'n': n}
        else:
            for g in groups:
                full = frame.loc[frame[p.group] == g]
                shown = full.sample(min(len(full), 2000), random_state=937).sort_index()
                panels.append({'name': g, 'n': len(full), 'shown': len(shown), 'points': shown[cols].to_numpy().tolist()})
            facet_data = {'panels': panels, 'mode': 'scatter', 'x_range': [frame[cols[0]].min(), frame[cols[0]].max()],
                          'y_range': [frame[cols[1]].min(), frame[cols[1]].max()], 'n': n}
        charts.append(chart('按组分面', 'facet', facet_data, xLabel=cols[0], yLabel=cols[1] if kind == 'scatter' else '频数'))
        tables['分面样本'] = [{'分组': panel['name'], 'n': panel['n'], '显示样本': panel['shown']} for panel in panels]
        tables['绘图样本'][0]['显示样本'] = sum(panel['shown'] for panel in panels)
    elif kind in distributions:
        charts = [c for c in distribution(frame[cols[0]].to_numpy(), cols[0]) if c['title'].endswith(' · '+distributions[kind])]
        if not charts:
            fail('此图需要至少 3 个有效观测及非恒定变量；常量可改用箱线图或 ECDF。')
        tables['变量概况'] = [{'变量': cols[0], 'n': n, '中位数': frame[cols[0]].median(), '最小值': frame[cols[0]].min(), '最大值': frame[cols[0]].max()}]
    elif kind == 'scatter':
        charts.append(chart(f'{cols[0]} × {cols[1]}', 'scatter', data, xLabel=cols[0], yLabel=cols[1]))
    elif kind == 'scatter3d':
        charts.append(chart('三维散点图', kind, data, xLabel=cols[0], yLabel=cols[1], zLabel=cols[2]))
        for x, y in itertools.combinations(range(3), 2):
            projection = {**data, 'points': sample[[cols[x], cols[y]]].to_numpy().tolist()}
            charts.append(chart(f'{cols[x]} × {cols[y]} · 二维投影', 'scatter', projection, xLabel=cols[x], yLabel=cols[y]))
    elif kind == 'bubble':
        if (frame[cols[2]] < 0).any():
            fail('气泡面积变量必须非负；负值不能表示面积，请更换第三个变量。')
        data['size_max'] = float(frame[cols[2]].max())
        charts.append(chart('气泡图', kind, data, xLabel=cols[0], yLabel=cols[1], zLabel=cols[2]))
    elif kind == 'parallel':
        charts.append(chart('平行坐标图', kind, {**data, 'dimensions': cols}))
    elif kind == 'scatter_matrix':
        for x, y in itertools.combinations(range(len(cols)), 2):
            charts.append(chart(f'{cols[x]} × {cols[y]}', 'scatter', {**data, 'points': sample[[cols[x], cols[y]]].to_numpy().tolist()}, xLabel=cols[x], yLabel=cols[y]))
    elif kind in ('grouped_box', 'violin'):
        boxes, outliers, summary, observations, densities = [], [], [], [], []
        for i, g in enumerate(groups):
            values = frame.loc[frame[p.group] == g, cols[0]].to_numpy()
            q1, median, q3 = np.quantile(values, [.25, .5, .75])
            iqr = q3-q1
            inside = values[(values >= q1-1.5*iqr) & (values <= q3+1.5*iqr)]
            boxes.append([float(inside.min()), float(q1), float(median), float(q3), float(inside.max())])
            outliers.extend([[i, float(v)] for v in values[(values < q1-1.5*iqr) | (values > q3+1.5*iqr)]])
            summary.append({'分组': g, 'n': len(values), 'Q1': q1, '中位数': median, 'Q3': q3})
            selected = np.unique(np.linspace(0, len(values)-1, min(160, len(values)), dtype=int))
            observations.extend([[i, float(v)] for v in np.sort(values)[selected]])
            if kind == 'violin':
                if len(values) >= 3 and np.ptp(values) > 0:
                    grid = np.linspace(values.min(), values.max(), 80)
                    density = stats.gaussian_kde(values)(grid)
                    densities.append({'group': i, 'points': np.column_stack((grid, density / density.max())).tolist()})
                else:
                    densities.append({'group': i, 'points': []})
        tables['分组分位数'] = summary
        charts.append(chart('小提琴与箱线观测点' if kind == 'violin' else '分组箱线图', kind,
                            {'categories': groups, 'boxes': boxes, 'values': outliers, 'observations': observations,
                             'densities': densities, 'group_n': [s['n'] for s in summary], 'n': n, 'shown': len(observations)}, xLabel=p.group, yLabel=cols[0]))
    else:
        frame[cols[0]] = frame[cols[0]].astype(str)
        categories = sorted(frame[cols[0]].unique().tolist())
        if len(categories) > 30:
            fail('分类字段超过 30 类，请更换字段或先合并类别。')
        series = []
        for g in groups:
            subset = frame.loc[frame[p.group] == g] if p.group else frame
            counts = subset[cols[0]].value_counts()
            series.append({'name': g, 'values': [int(counts.get(c, 0)) for c in categories]})
        tables['分类频数'] = [{'类别': c, **{s['name']: s['values'][i] for s in series}} for i, c in enumerate(categories)]
        charts.append(chart('分类频数图', kind, {'categories': categories, 'series': series, 'n': n}, xLabel=cols[0], yLabel='频数'))
    notes = ['绘图描述数据分布和变量关系，不提供显著性检验或因果结论。', '数值图使用联合完整记录；选择顺序对应 X、Y、Z（气泡面积）。']
    if kind in ('grouped_box', 'violin'):
        notes.append('箱线与离群值按全部完整记录计算；每组最多 160 个按排序位置选取的真实观测点，抖动仅改变横向位置。')
    if kind == 'violin':
        notes.append('小提琴使用 Gaussian KDE / Scott 带宽，在观测范围内绘制、每组等最大宽度；宽度不表示样本量。常量或少于 3 个样本的组只显示箱线与观测点。')
    if kind in distributions:
        notes.append('分布图沿用描述统计算法：箱线最多 160 个排序观测点、ECDF 最多 500 节点、Q–Q 最多 500 点；密度为 Gaussian KDE / Scott 带宽。')
    if p.facet:
        notes.append('所有分面共用坐标范围；直方图共用完整数据的等宽分箱及频数轴。散点图每组最多 2000 行，固定种子 937；各面板列示完整 n 与显示数量。')
    if sampled and not p.facet:
        notes.append(f'有效样本 {n} 行；固定种子 937 均匀抽样显示 {LIMIT} 行，统计表使用全部完整记录。')
    if kind == 'scatter3d':
        notes.append('三维图支持拖动旋转、滚轮缩放。附三张二维投影供精确比较和矢量导出。')
    if kind == 'bubble':
        notes.append('气泡面积正比于第三个变量；零面积记录隐藏，缩放上限由完整数据的最大值确定。')
    return {'tables': tables, 'charts': charts, 'notes': notes,
            'warnings': [f'联合完整记录：删除 {len(df)-n} 行。'] if len(df) != n else []}
