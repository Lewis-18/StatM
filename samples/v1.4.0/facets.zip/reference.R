# Independent R reference; package algorithms may differ.
# install.packages(c("psych", "car", "lmtest", "effectsize"))
df <- read.csv("469102e7-224d-455f-a183-f5c55652402d.csv", check.names=FALSE)
cols <- c("X1")
alpha <- 0.05
fields <- c("X1", "group")
d <- df[, fields, drop=FALSE]
for (col in cols) d[[col]][!is.finite(d[[col]])] <- NA
d <- d[complete.cases(d), , drop=FALSE]
g <- factor(d[["group"]])
x <- d[[cols[1]]]
hist(x, xlab=cols[1])
# Facets share complete-data limits and histogram breaks.
par(mfrow=c(ceiling(nlevels(g)/2),2))
breaks <- seq(min(d[[cols[1]]]),max(d[[cols[1]]]),length.out=21)
for (group in levels(g)) hist(d[[cols[1]]][g==group], breaks=breaks, main=group, xlab=cols[1])
# R reference uses 20 bins; the exact StatM edges are in charts.json.
