# Independent R reference; package algorithms may differ.
# install.packages(c("psych", "car", "lmtest", "effectsize"))
df <- read.csv("469102e7-224d-455f-a183-f5c55652402d.csv", check.names=FALSE)
cols <- c("Q1", "Q2", "Q3", "Q4")
alpha <- 0.05
d <- df[, cols, drop=FALSE]
for (col in cols) d[[col]][!is.finite(d[[col]])] <- NA
d <- d[complete.cases(d), , drop=FALSE]
d[["Q4"]] <- 6.0 - d[["Q4"]]
psych::alpha(d, check.keys=FALSE, use="complete.obs")
# Raw alpha; intervals can differ from the Feldt calculation in StatM.
