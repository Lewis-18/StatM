"""Run from any directory: python reproduce.py. No StatM server is needed."""
from pathlib import Path
import hashlib, importlib, json, math, sys
ROOT=Path(__file__).resolve().parent
manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
for name, expected in manifest['files'].items():
    path=(ROOT/name).resolve()
    if not path.is_relative_to(ROOT) or hashlib.sha256(path.read_bytes()).hexdigest()!=expected:
        raise SystemExit('Checksum failed: '+name)
if manifest['algorithm_matches_record'] is False:
    raise SystemExit('The current numerical source differs from the recorded analysis. This archive preserves the result, but cannot certify a rerun with different source.')
sys.path.insert(0,str(ROOT/'runtime'))
import pandas as pd
from app.schemas.requests import AnalysisIn
from app.utils.common import clean
analysis=json.loads((ROOT/'analysis.json').read_text(encoding='utf-8'))
df=pd.read_json(ROOT/'data/dataset.json',orient='table',precise_float=True)
params=AnalysisIn(**analysis['params'])
module=importlib.import_module('app.statistics.'+analysis['kind'])
if analysis['kind']=='batch':
    reference=pd.read_json(ROOT/'data/reference.json',orient='table',precise_float=True)
    metadata=json.loads((ROOT/'comparison-metadata.json').read_text(encoding='utf-8'))
    actual=clean(module.run(df,params,reference,metadata))
else:actual=clean(module.run(df,params))
expected=json.loads((ROOT/'result.json').read_text(encoding='utf-8'))
differences=[]
def compare(a,b,path='result'):
    if isinstance(a,bool) or isinstance(b,bool):
        if type(a)!=type(b) or a!=b:differences.append(path)
    elif isinstance(a,(int,float)) and isinstance(b,(int,float)):
        if not math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-10):differences.append(path)
    elif isinstance(a,dict) and isinstance(b,dict):
        if set(a)!=set(b):differences.append(path+' keys')
        for key in a.keys()&b.keys():compare(a[key],b[key],path+'.'+key)
    elif isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):differences.append(path+' length')
        for i,(x,y) in enumerate(zip(a,b)):compare(x,y,f'{path}[{i}]')
    elif a!=b:differences.append(path)
for key in ('tables','charts','notes','warnings'):compare(expected.get(key),actual.get(key),key)
(ROOT/'reproduced-result.json').write_text(json.dumps(actual,ensure_ascii=False,indent=2,allow_nan=False),encoding='utf-8')
report={'status':'PASS' if not differences else 'FAIL','differences':differences[:100],'difference_count':len(differences),'relative_tolerance':1e-8,'absolute_tolerance':1e-10,'recorded_source_available':manifest['algorithm_matches_record'] is not None}
(ROOT/'reproduction-check.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
print(json.dumps(report,indent=2))
raise SystemExit(1 if differences else 0)
