from typing import Literal
from pydantic import BaseModel,Field,ConfigDict,model_validator
class Strict(BaseModel): model_config=ConfigDict(extra='forbid')
class ProjectIn(Strict):
    name:str=Field(min_length=1,max_length=150)
    description:str=Field(default='',max_length=2000)
class BatchField(Strict):
    left:str=Field(min_length=1,max_length=500)
    right:str=Field(min_length=1,max_length=500)
    kind:Literal['numeric','category']='numeric'
class AnalysisIn(Strict):
    dataset_id:str
    columns:list[str]=Field(default_factory=list,max_length=30)
    method:str='pearson'
    test:str='one_sample_t'
    posthoc:Literal['none','auto','tukey','games_howell','dunn_holm']='auto'
    target:str|None=None
    group:str|None=None
    label:str|None=None
    alpha:float=Field(default=0.05,gt=0,lt=1)
    mu:float=0
    standardize:bool=True
    components:int|None=Field(default=None,ge=1)
    missing:Literal['drop','error']='drop'
    reverse_columns:list[str]=Field(default_factory=list,max_length=30)
    score_min:float|None=Field(default=None,allow_inf_nan=False)
    score_max:float|None=Field(default=None,allow_inf_nan=False)
    rotation:Literal['none','varimax']='varimax'
    facet:bool=False
    reference_id:str|None=None
    mappings:list[BatchField]=Field(default_factory=list,max_length=12)
    metadata_confirmed:bool=False
    chart_type:Literal['scatter','scatter3d','bubble','parallel','scatter_matrix','grouped_box','violin','category_bar','histogram','boxplot','ecdf','density','qq']='scatter3d'
class CleanIn(Strict):
    operation:Literal['drop_missing','mean','median','mode','drop_duplicates']
    columns:list[str]=Field(default_factory=list)

class QualityRule(Strict):
    column:str=Field(min_length=1,max_length=500)
    check:Literal['required','unique','numeric','range','category']
    minimum:float|None=Field(default=None,allow_inf_nan=False)
    maximum:float|None=Field(default=None,allow_inf_nan=False)
    allowed:list[str]=Field(default_factory=list,max_length=100)
    @model_validator(mode='after')
    def valid_range(self):
        if self.check=='range' and self.minimum is None and self.maximum is None:raise ValueError('请设置至少一个范围边界。')
        if self.minimum is not None and self.maximum is not None and self.minimum>self.maximum:raise ValueError('下限不能大于上限。')
        if self.check=='category' and not self.allowed:raise ValueError('请设置允许的类别。')
        if any(len(s)>500 for s in self.allowed):raise ValueError('类别文本过长。')
        return self
class QualityIn(Strict):
    rules:list[QualityRule]=Field(default_factory=list,max_length=50)

class RuleSetIn(QualityIn):
    name:str=Field(min_length=1,max_length=150)
    dataset_id:str

class VariableInfo(Strict):
    label:str=Field(default='',max_length=200)
    unit:str=Field(default='',max_length=80)
    description:str=Field(default='',max_length=2000)
    codes:dict[str,str]=Field(default_factory=dict,max_length=100)
    scale:Literal['unspecified','nominal','ordinal','continuous']='unspecified'
    @model_validator(mode='after')
    def bounded_codes(self):
        if any(len(k)>200 or len(v)>500 for k,v in self.codes.items()):raise ValueError('变量编码文本过长。')
        return self

class DictionaryIn(Strict):
    variables:dict[str,VariableInfo]=Field(default_factory=dict,max_length=500)

class MergeIn(Strict):
    left_id:str
    right_id:str
    left_keys:list[str]=Field(min_length=1,max_length=8)
    right_keys:list[str]=Field(min_length=1,max_length=8)
    how:Literal['left','inner','outer']='left'
    relationship:Literal['one_to_one','one_to_many','many_to_one','many_to_many']='one_to_one'
    name:str=Field(default='关联数据',min_length=1,max_length=150)
    @model_validator(mode='after')
    def paired_keys(self):
        if len(self.left_keys)!=len(self.right_keys) or len(set(self.left_keys))!=len(self.left_keys) or len(set(self.right_keys))!=len(self.right_keys):raise ValueError('请逐一对应选择不重复的关联键。')
        return self

class SheetIn(Strict):
    sheet:str=Field(min_length=1,max_length=200)

class CompositionIn(Strict):
    chart_ids:list[str]=Field(min_length=2,max_length=4)
    layout:Literal['two','four']='two'
    background:Literal['white','black']='white'
    @model_validator(mode='after')
    def panel_count(self):
        if len(self.chart_ids)!=(2 if self.layout=='two' else 4) or len(set(self.chart_ids))!=len(self.chart_ids):raise ValueError('请选择布局所需的不同图表。')
        return self
