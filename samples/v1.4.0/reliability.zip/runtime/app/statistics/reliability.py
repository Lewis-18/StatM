"""Raw-score alpha with one common complete-case sample for every diagnostic."""
import numpy as np
from scipy import stats
from app.utils.common import numeric, fail, chart


def coefficient(values):
    k = values.shape[1]
    variance = values.sum(axis=1).var(ddof=1)
    return float(k/(k-1)*(1-values.var(axis=0, ddof=1).sum()/variance)) if k > 1 and variance > 0 else None


def run(df, p):
    if len(p.columns) < 2:
        fail('信度分析至少需要两个题项。')
    if len(set(p.reverse_columns)) != len(p.reverse_columns) or not set(p.reverse_columns) <= set(p.columns):
        fail('反向题必须是不重复的已选题项。')
    if (p.score_min is None) != (p.score_max is None) or (p.score_min is not None and p.score_min >= p.score_max):
        fail('请同时设置有效的量表下限和上限。')
    if p.reverse_columns and p.score_min is None:
        fail('反向计分需要明确的量表下限和上限。')
    frame = numeric(df, p.columns, p.missing).copy()
    # Validate observed scores even in rows later excluded for another missing item.
    if p.score_min is not None:
        observed = df[p.columns].replace([np.inf, -np.inf], np.nan)
        if ((observed < p.score_min) | (observed > p.score_max)).any().any():
            fail('观测题分超出所设量表范围，请核对上下限。')
    for col in p.reverse_columns:
        frame[col] = p.score_min + p.score_max - frame[col]
    values = frame.to_numpy(dtype=float)
    n, k = values.shape
    alpha = coefficient(values)
    if alpha is None or not np.isfinite(alpha):
        fail('总分方差为零，无法计算 Cronbach’s α。')
    # Feldt interval, kept at full precision (some libraries round to 3 decimals).
    lower = 1-(1-alpha)*stats.f.isf(p.alpha/2, n-1, (n-1)*(k-1))
    upper = 1-(1-alpha)*stats.f.isf(1-p.alpha/2, n-1, (n-1)*(k-1))
    diagnostics = []
    for i, name in enumerate(p.columns):
        rest = np.delete(values, i, axis=1)
        total = rest.sum(axis=1)
        correlation = float(np.corrcoef(values[:, i], total)[0, 1]) if np.ptp(total) > 0 else None
        diagnostics.append({'variable': name, 'n': n, 'mean': values[:, i].mean(), 'std': values[:, i].std(ddof=1),
                            'corrected item-total r': correlation, 'alpha if deleted': coefficient(rest), 'reversed': name in p.reverse_columns})
    warnings = [f'完整案例分析：删除 {len(df)-n} 行。']
    if alpha < 0:
        warnings.append('α 为负值，请检查反向计分、题项方向及量表结构。')
    if k == 2:
        warnings.append('仅有两个题项；删除任一题项后的 α 无定义。')
    return {'tables': {'信度汇总': [{'n': n, 'items': k, 'Cronbach alpha': alpha, 'CI low': lower, 'CI high': upper, 'confidence': 1-p.alpha}],
                       '题项诊断': diagnostics},
            'charts': [chart('校正题总相关', 'bar', {'x': p.columns, 'y': [r['corrected item-total r'] for r in diagnostics]}, yLabel='校正题总相关')],
            'warnings': warnings,
            'notes': ['使用原始题分 Cronbach’s α；所有统计及删题诊断使用同一批完整案例，区间采用 Feldt 方法。',
                      'α 不检验单维性，也不证明效度；不按阈值自动判定合格或删除题项。完整案例删除可能引入选择偏倚。',
                      '反向计分为下限＋上限−原分；仅用于本次计算，不修改原始数据。']}
