StatM 可复现分析包

1. 解压到一个目录。保留所有文件的相对位置。
2. 使用 environment.json 中记录的 Python 版本，创建独立环境并安装 requirements.txt：
   python -m venv .venv
   .venv\Scripts\python.exe -m pip install -r requirements.txt
3. 运行：.venv\Scripts\python.exe reproduce.py
4. 查看 reproduced-result.json 和 reproduction-check.json；PASS 表示统计结果和图表数据在标明容差内一致。

复现入口包含本次分析所需的统计源码，不依赖 StatM 安装目录或本地服务器。安装 Python 和依赖可能需要网络或离线 wheel。
data/dataset.json 保留字段类型，是计算输入；CSV 仅方便查看。包中包含本次完整分析数据，请按研究的数据共享范围保管。
reference.R 是独立参考实现，算法可能不同，不作为 Python 一致性验收入口。
charts.json 保存图表数据与已持久化显示设置；不承诺截图逐像素相同，不含未保存的临时缩放或三维视角。
旧记录若无算法版本标识，不能证明当前源码就是其原始源码，重跑会明确给出数值一致性结果。
SHA256SUMS.txt 和 manifest.json 的校验可检测意外损坏，不是数字签名。
